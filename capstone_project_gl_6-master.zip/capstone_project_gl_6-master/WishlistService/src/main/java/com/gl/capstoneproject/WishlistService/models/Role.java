package com.gl.capstoneproject.WishlistService.models;

import org.springframework.stereotype.Component;

@Component
public class Role {
	
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
