package com.gl.capstone.ShopForHomeMain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopForHomeMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
