package com.gl.capstone.DiscountCouponsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscountCouponsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
